package com.example.dailycode_buffer.Controller;

import com.example.dailycode_buffer.entity.Department;
import com.example.dailycode_buffer.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
//import com.example.dailycode_buffer.entity.Department;
@RestController
public class DepartmentController {
    @Autowired
    Department department;

    @Autowired
    DepartmentService departmentService;


    @PostMapping("/departments")
    public Department saveDepartment(@RequestBody Department department){
        return departmentService.saveDepartment(department);

    }
}
