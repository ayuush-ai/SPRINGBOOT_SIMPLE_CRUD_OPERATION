package com.example.dailycode_buffer.service;

import com.example.dailycode_buffer.entity.Department;

public interface DepartmentService {
   public  Department saveDepartment(Department department);
}
