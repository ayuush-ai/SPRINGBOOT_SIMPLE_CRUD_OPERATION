package com.example.dailycode_buffer.service;

import com.example.dailycode_buffer.entity.Department;

import com.example.dailycode_buffer.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class DepartmentServiceImpl implements DepartmentService{


    @Autowired
    DepartmentRepository departmentRepository;
    public Department saveDepartment(Department department){
        return departmentRepository.save(department);
    }
}
